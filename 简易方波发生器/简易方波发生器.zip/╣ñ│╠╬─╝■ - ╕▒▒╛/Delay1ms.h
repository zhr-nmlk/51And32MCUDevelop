#ifndef __Delay1ms_H__
#define __Delay1ms_H__

void Delay1ms(unsigned int xms);
void Delay100us();

#endif