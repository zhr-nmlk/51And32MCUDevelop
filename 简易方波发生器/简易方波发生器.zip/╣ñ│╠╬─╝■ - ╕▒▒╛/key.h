#ifndef __KEY_H__
#define __KEY_H__

unsigned char key_driver(void);
unsigned char key_read(void);

#endif